/*
nome de todas as cidades onde a locadora tem clientes.
Mas por favor, não repita o nome da cidade.

Rodrigo CavanhaMan
URI 2615
Expandindo o Negocio
*/

select distinct city
 from customers;
