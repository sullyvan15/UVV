#include <stdio.h>
#include <stdlib.h>

int main()
{   float Quantidade, Conversao;
    printf("Entre com  a quantidade em R$: ");
    scanf("%f" , &Quantidade);
    Conversao = Quantidade /4.42; // Real p/ euro
    printf("Quantidade em Euro: %.2f\n", Conversao);
    Conversao = 1.12/4.42 * Quantidade; // Real / d�lar
    printf("Quantidade em dolar: %.2f\n", Conversao);

    return 0;
}
