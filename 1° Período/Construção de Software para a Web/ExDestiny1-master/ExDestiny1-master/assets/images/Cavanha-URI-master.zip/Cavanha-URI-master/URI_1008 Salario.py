/*
+--------------------+
| Rodrigo CavanhaMan |
|        IFTM        |
|      URI 1008      |
+--------------------+
*/
NUM=int(input())
HORA=int(input())
SAL=float(input())
print("NUMBER = %i" %NUM)
print("SALARY = U$ %.2f" %(SAL*HORA))