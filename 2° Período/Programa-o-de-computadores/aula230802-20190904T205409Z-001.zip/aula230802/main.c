#include <stdio.h>
#include <stdlib.h>

int main()
{   int Contador = 0, Soma = 0, Quantidade;
    float Media;
    printf("Os pares entre 0 e 100 sao: \n");
    while (Contador <=100);
    {
        if (Contador %2 ==0)
        {
            printf("Par; %i\n", Contador);
            Soma = Soma + Contador;
            Quantidade++;

        }
        Contador++;
    }

    Media = 1.0 * Soma /Quantidade;
    printf("Soma dos pares entre 0 e 100 eh: %i\n", Soma);
    printf("Media dos Pares : %.1f\n", Media);



    return 0;
}
