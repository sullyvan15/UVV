/*
+------------------+
|Rodrigo CavanhaMan|
|      Saida8      |
|     URI 2755     |
+------------------+
*/
public class Main {
	public static void main(String[] args) {
		System.out.println("\"Ro'b'er\tto\\/\"");
		System.out.println("(._.) ( l: ) ( .-. ) ( :l ) (._.)");
		System.out.println("(^_-) (-_-) (-_^)");
		System.out.println("(\"_\") (\'.\')");
	}
}
