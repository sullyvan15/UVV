#include <stdio.h>
#include <stdlib.h>

int main()
{   int Idade;
    printf("Entre com sua Idade (em anos)");
    scanf("%i",Idade);
    if (Idade <15)
        printf("Fora da Tabela.\n");
    else
    {
        if(Idade <= 20)
            printf("Geracao: Z.\n");
        else if (Idade <= 34)
            printf ("Geracao: Y.\n");
        else if (Idade <= 50)
            printf ("Geracao: X.\n");
        else if (Idade <= 64)
            printf ("Geracao: BABY BOOMERS.\n");
        else
            printf ("Geracao: SILENCIOSA.\n");
    }

}
