/*
substituir todo caractere 'H1' ( Hemaglutinina ) por 'X' ( Xenomorphina ).

Rodrigo Cavanhaman
URI 2746
Vírus
 */
select REPLACE(name, 'H1', 'X')
    from virus;
