# Cavanha-URI
All my solutions for problems from URI Online Judge - Java, C++, SQL and some Python.
(To compile, all the java files will have to be renamed to Main)
Todas as minhas soluções para problemas do URI - Java, C++, SQL e um pouco de Python.
(Para compilar, os arquivos java terão que ter o nome alterado para Main)
