
package DAO.Tabelas;

/**
 *
 * @author Sullyvan Marks
 */

public class Tabelas {
    public static final String instrutor = "instrutor";
    public static final String oferta = "oferta";
    public static final String curso = "curso";
  
}
