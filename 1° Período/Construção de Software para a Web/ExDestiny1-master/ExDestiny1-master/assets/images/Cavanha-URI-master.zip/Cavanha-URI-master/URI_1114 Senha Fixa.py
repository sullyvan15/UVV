/*
+--------------------+
| Rodrigo CavanhaMan |
|        IFTM        |
|      URI 1114      |
+--------------------+
*/
SENHA=0
while SENHA!="2002":
    SENHA=input()
    if SENHA!="2002":
        print("Senha Invalida")
    else:
        print("Acesso Permitido")