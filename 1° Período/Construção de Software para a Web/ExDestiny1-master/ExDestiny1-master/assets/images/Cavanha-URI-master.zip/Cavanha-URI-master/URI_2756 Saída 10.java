/*
+------------------+
|Rodrigo CavanhaMan|
|      Saida10     |
|     URI 2756     |
+------------------+
*/
public class Main {
	public static void main(String[] args) {
		System.out.printf("       A\n");
		System.out.printf("      B B\n");
		System.out.printf("     C   C\n");
		System.out.printf("    D     D\n");
		System.out.printf("   E       E\n");
		System.out.printf("    D     D\n");
		System.out.printf("     C   C\n");
		System.out.printf("      B B\n");
		System.out.printf("       A\n");
	}
}
