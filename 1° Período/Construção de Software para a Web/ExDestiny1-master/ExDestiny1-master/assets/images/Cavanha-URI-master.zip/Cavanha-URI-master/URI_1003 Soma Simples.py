/*
+--------------------+
| Rodrigo CavanhaMan |
|        IFTM        |
|      URI 1003      |
+--------------------+
*/
A = input()
B = input()
print("SOMA = " +str(A+B))