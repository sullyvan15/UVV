/*
+--------------------+
| Rodrigo CavanhaMan |
|        IFTM        |
|      URI 2483      |
+--------------------+
*/
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int i = sc.nextInt();
		System.out.printf("Feliz nat");
		for (int x=0 ; x<i ; x++)
			System.out.printf("a");
		System.out.printf("l!\n");

		sc.close();
	}
}