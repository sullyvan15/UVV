/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Questao1;

import java.util.Scanner;

/**
 *
 * @author alunodev10
 */
public class Executavel {
    private static String Imposto;
    public static void main(String[] args) {
        
       Imovel n1 = new Imovel();
       Multa m1 = new Multa();
        
       Scanner sc = new Scanner(System.in);
       System.out.println("Qual o nome do proprietario do imovel? ");
       String nome = sc.next(); 
       
       Scanner sc1 = new Scanner(System.in);
       System.out.println("Qual o Valor da sua divida? ");
       float divida = sc1.nextFloat();
       
       System.out.println("Olá " + nome + " o valor da sua divade é " + divida + "!");
       
       Scanner sc2 = new Scanner(System.in);
       System.out.println("Quantos meses está devendo? ");
       Integer mesesAtraso = sc2.nextInt();
       
       System.out.println("Você está com: " + mesesAtraso + " meses de atraso!");
    
       m1.Calculo(mesesAtraso);
       
      System.out.println("Vocês está devendo: " + m1.getImposto());
    }
}

        