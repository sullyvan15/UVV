/*
+------------------+
|Rodrigo CavanhaMan|
|      Saida3      |
|     URI 2749     |
+------------------+
*/
public class Main {
	public static void main(String[] args) {
		System.out.printf("---------------------------------------\n");
		System.out.printf("|x = 35                               |\n");
		System.out.printf("|                                     |\n");
		System.out.printf("|               x = 35                |\n");
		System.out.printf("|                                     |\n");
		System.out.printf("|                               x = 35|\n");
		System.out.printf("---------------------------------------\n");
	}
}