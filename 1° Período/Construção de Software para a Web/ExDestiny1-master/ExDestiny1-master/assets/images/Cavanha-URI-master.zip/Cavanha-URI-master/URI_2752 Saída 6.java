/*
+------------------+
|Rodrigo CavanhaMan|
|      Saida6      |
|     URI 2752     |
+------------------+
*/
public class Main {
	public static void main(String[] args) {
		int a,b;
		System.out.printf("<AMO FAZER EXERCICIO NO URI>\n");
		System.out.printf("<    AMO FAZER EXERCICIO NO URI>\n");
		System.out.printf("<AMO FAZER EXERCICIO >\n");
		System.out.printf("<AMO FAZER EXERCICIO NO URI>\n");
		System.out.printf("<AMO FAZER EXERCICIO NO URI    >\n");
		System.out.printf("<AMO FAZER EXERCICIO NO URI>\n");
		System.out.printf("<          AMO FAZER EXERCICIO >\n");
		System.out.printf("<AMO FAZER EXERCICIO           >\n");
	}
}