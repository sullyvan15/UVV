/*
calcular e exibir o valor médio do preço dos produtos.

Rodrigo CavanhaMan
URI 2610
Valor Médio dos Produtos
*/

select round(avg(price),2) from products;