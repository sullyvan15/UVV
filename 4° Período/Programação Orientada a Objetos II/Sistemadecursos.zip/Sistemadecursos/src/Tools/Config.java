
package Tools;

/**
 *
 * @author Sullyvan Marks
 */
public interface Config {
    public static final String NOME_DRIVER = "com.mysql.cj.jdbc.Driver";     
    public static final String BD_URL = "jdbc:mysql://localhost:3306/mydb?useTimezone=true&serverTimezone=UTC";
    public static final String BD_LOGIN  = "root";
    public static final String BD_PASS = "2001";
}// jdbc:mysql://localhost:3306/mydb?zeroDateTimeBehavior=CONVERT_TO_NULL
