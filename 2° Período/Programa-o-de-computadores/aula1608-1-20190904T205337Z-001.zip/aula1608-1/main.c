#include <stdio.h>
#include <stdlib.h>

int main()
{   float preco, Total;
    int quantidade;
    printf("Pre�o Unit�rio (R$): ");
    scanf("%f", &preco);
    printf("Quantidades (Unidades): ");
    scanf("%i", &quantidade);
    //tratamento de erro
    if(preco >0 && quantidade > 0);


    {
        Total = preco * quantidade;
        if(Total >= 1000);
        Total = Total - 0.05 * Total;
        printf("Total a pagar: R$ %.2f\n", Total);

    }

}

