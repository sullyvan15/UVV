#include <stdio.h>
#include <stdlib.h>

int main()
{
    float Preco, Reajuste, Total;
    char Opcao;
    printf("Dados da Mercadoria:\n");
    printf("Entre com o preco da Mercadoria: R$");
    scanf("%f", &Preco);
    if (Preco <= 0)
        printf("ERRO no preco .\n");
    else {
        printf("Reajuste (em porcentagem): ");
        scanf ("%f", &Reajuste);
        if (Reajuste >0) {
            printf ("Opcao ((A)CRESCIMO ou (D)esconto)");
            scanf ("n%c", &Opcao);
            if (Opcao != 'A' && Opcao != 'a' && Opcao != 'D' && Opcao != 'd')
                print ("opcao incorreta.\n");
            else {
                if(Opcao == 'a' || Opcao == 'A')
                {
                    Total = Preco + Reajuste / 100 * Preco;
                    printf("Valor com acrescimo de %.1f %% = R$ %.2f\n", Reajuste, Total);
                }
                else{
                    Total = Preco* (1 - Reajuste / 100);
                    printf("Valor com desconto de %.1f %% = R$ % .2f\n", Reajuste, Total);
                }
            }
        }

    }

    return 0;
}
