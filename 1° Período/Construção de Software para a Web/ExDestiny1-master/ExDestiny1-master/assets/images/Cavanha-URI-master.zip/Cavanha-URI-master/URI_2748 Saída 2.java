/*
+------------------+
|Rodrigo CavanhaMan|
|      Saida2      |
|     URI 2748     |
+------------------+
*/
public class Main {
	public static void main(String[] args) {
		System.out.printf("---------------------------------------\n");
		System.out.printf("|        Roberto                      |\n");
		System.out.printf("|                                     |\n");
		System.out.printf("|        5786                         |\n");
		System.out.printf("|                                     |\n");
		System.out.printf("|        UNIFEI                       |\n");
		System.out.printf("---------------------------------------\n");
	}
}