/*
o maior e o menor preço da tabela produtos.

Rodrigo CavanhaMan
URI 2608
Maior e Menor Preço
*/

select max(price), min(price)
 from products;