/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Questao1;

/**
 *
 * @author alunodev10
 */
public class Multa {
    public float divida, Imposto;
    public Integer mesesAtraso;
    
    /**
     * Calcula o imposto
     * @param Imposto
     * @param mesesAtraso
     * @return 
     */
    public double Calculo(double Imposto){
         if (mesesAtraso >= 0 || mesesAtraso <= 5) {
             Imposto = (float) (divida * 1.01);
        } 
         else if(mesesAtraso >=6 || mesesAtraso <= 8){
            Imposto = (float) (divida * 1.023);
        }
        else if(mesesAtraso >= 9 || mesesAtraso <= 10){
            Imposto = (float) (divida * 1.03);
        }
        else if(mesesAtraso >= 11 || mesesAtraso <= 12){
            Imposto = (float) (divida * 1.054);
        }
        else if(mesesAtraso > 12){
            Imposto =  (float) (divida * 1.1);
        }
        else {
            Imposto = (float) (divida * 1.01);
        }
    return 0;   
}
    public Multa() {
    }

    public Multa(float divida, int mesesAtraso) {
        this.divida = divida;
        this.mesesAtraso = mesesAtraso;
    }

    public float getDivida() {
        return divida;
    }

    public void setDivida(float divida) {
        this.divida = divida;
    }

    public float getImposto() {
        return Imposto;
    }

    public void setImposto(float Imposto) {
        this.Imposto = Imposto;
    }

    public int getMesesAtraso() {
        return mesesAtraso;
    }

    public void setMesesAtraso(int mesesAtraso) {
        this.mesesAtraso = mesesAtraso;
    }
}  
